"""
Parsers and serializers for SPARQL Result formats
"""
